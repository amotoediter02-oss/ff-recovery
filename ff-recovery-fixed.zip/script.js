const form=document.getElementById('form');
const uid=document.getElementById('uid');
const error=document.getElementById('error');
const formArea=document.getElementById('formArea');
const success=document.getElementById('success');
const message=document.getElementById('message');

uid.addEventListener('input',()=>{
 uid.value=uid.value.replace(/\\D/g,'');
 error.textContent=uid.value && uid.value.length<6?'UID should contain at least 6 digits.':'';
});

form.addEventListener('submit',e=>{
 e.preventDefault();
 const id=uid.value.trim();
 if(!/^\\d{6,20}$/.test(id)){error.textContent='Please enter a valid 6–20 digit UID.';return;}
 formArea.classList.add('hidden');
 success.classList.remove('hidden');
 message.textContent='Recovery request prepared for UID '+id+'. No password or OTP was collected. Continue to the official support service for ownership verification.';
});

document.getElementById('support').onclick=()=>{
 window.open('https://ffsupport.garena.com/','_blank','noopener,noreferrer');
};
document.getElementById('again').onclick=()=>{
 form.reset();error.textContent='';success.classList.add('hidden');formArea.classList.remove('hidden');
 location.hash='recovery';
};
